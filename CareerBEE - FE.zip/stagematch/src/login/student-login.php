<?php
session_start();  // Avvia la sessione
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../global.css">
    <link rel="stylesheet" href="./login.css">z
    <title>CareerBEE</title>
</head>

<body>
    <nav class="navbar">
        <div class="menu">
            <div class="logo-wrapper">
                <img class="logo-app" src="../assests/logo-app.png" alt="logo_img">
                <a href="../index/index.html" class="logo">CareerBEE</a>
            </div>
            <a href="#">Aziende</a>
            <a href="#">Scuole</a>
        </div>

        <div class="logAndSign">

            <a class="button_1" href="../registration/signin.html">REGISTRATI</a>
        </div>
    </nav>
    <div id="main">
        <div id="loginCard">
            <h1>Accesso Studente</h1>
            <form action="" method="POST">
                <div class="input">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" placeholder="Username" required>
                </div>
                <div class="input">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" placeholder="Password" required>
                </div>
                <input type="submit" name="submit" value="Accedi">
            </form>
            <a class="turn-back-button" href="./login.html">
                <img src="../assests/back-icon-png-16-101190050.jpg" alt="back_icon">
            </a>
        </div>
    </div>
    <footer>
        <div class="info">
            <a href="#">I Nostri Servizi</a>
            <a href="#">Scopri il Nostro Team</a>
            <a href="#">Dacci un Feedback</a>
        </div>
        <div class="marketing">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Mollitia rem cum perferendis fugiat delectus ipsum eligendi, hic beatae magnam omnis nam dolor fuga praesentium consequatur at voluptates ad dolore repellendus!</div>
        <div class="link">
            <a href="#">I Nostri Servizi</a>
            <a href="#">Scopri il Nostro Team</a>
            <a href="#">Dacci un Feedback</a>
        </div>
    </footer>
</body>

</html>

<?php
// Inizializza la sessione
session_start();

if (isset($_POST['submit'])) {
    // URL di base per l'API
    $baseUrl = "https://744e-2-115-95-150.ngrok-free.app/Hackaton/api/user/login.php";

    // Parametri da inviare
    $username = urlencode($_POST['username']);
    $password = urlencode($_POST['password']);

    // Costruzione del link completo con i parametri GET
    $url = $baseUrl . "?username={$username}&password={$password}";

    // Inizializzazione di cURL
    $ch = curl_init($url);

    // Configura le opzioni di cURL
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Ritorna la risposta come stringa
    curl_setopt($ch, CURLOPT_HTTPGET, true);       // Usa il metodo GET

    // Esegui la richiesta
    $response = curl_exec($ch);

    // Gestione errori
    if (curl_errno($ch)) {
        echo "Errore cURL: " . curl_error($ch);
    } else {
        // Analizza la risposta JSON
        $json = json_decode($response, true);

        // Controlla e stampa il risultato
        if ($json && isset($json['login'])) {
            if ($json['login'] === true) {
                // Assegna l'ID utente alla sessione
                $_SESSION["user_id"] = $json["id"];

                // Reindirizza alla pagina dashboard dello studente
                header("Location: ../student/student-dashboard.html");
                exit();  // Interrompe l'esecuzione del codice dopo il reindirizzamento
            } else {
                // Login fallito
                echo "<p>Login fallito. Utente non trovato o credenziali errate.</p>";
            }
        } else {
            echo "<p>Risposta non valida dal server.</p>";
        }
    }

    // Chiudi la sessione cURL
    curl_close($ch);
}
?>