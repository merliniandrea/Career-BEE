<?php
session_start();  // Avvia la sessione

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recupera i dati del form
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $a_email = isset($_POST['a_email']) ? $_POST["a_email"] : null;

    // Dati da inviare all'API come JSON
    $data = array(
        'username' => $username,
        'password' => $password,
        'email' => $email,
        'a_email' => $a_email
    );

    // URL dell'API
    $url = 'https://744e-2-115-95-150.ngrok-free.app/Hackaton/api/user/signup.php';

    // Inizializza cURL
    $ch = curl_init($url);

    // Impostazioni cURL
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // Ritorna la risposta come stringa
    curl_setopt($ch, CURLOPT_POST, true);            // Metodo POST
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data)); // Dati da inviare
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); // Headers per JSON

    // Esegui la richiesta e ricevi la risposta
    $response = curl_exec($ch);

    // Controlla eventuali errori
    if (curl_errno($ch)) {
        echo 'Errore cURL: ' . curl_error($ch);
    } else {
        // Decodifica la risposta JSON
        $responseData = json_decode($response, true);

        // Gestisci la risposta
        if (isset($responseData['message']) && $responseData['message'] === 'Signup successful') {
            // Reindirizza alla pagina dashboard dello studente
            $_SESSION["user_id"] = $responseData['user_id']; // Ad esempio, memorizziamo l'ID utente nella sessione
            header("Location: ../student/student-dashboard.html");
            exit(); // Ferma l'esecuzione del codice dopo il reindirizzamento
        } else {
            echo "<p>Login fallito: " . ($responseData['message'] ?? 'Errore sconosciuto') . "</p>";
        }
    }

    // Chiudi la sessione cURL
    curl_close($ch);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../global.css">
    <link rel="stylesheet" href="./signin.css">
    <title>CarreerBEE</title>
</head>

<body>
    <nav class="navbar">
        <div class="menu">
        <div class="logo-wrapper">
                <img class="logo-app" src="../assests/logo-app.png" alt="logo_img">
                <a href="../index/index.html" class="logo">CareerBEE</a>
            </div>
            <a href="#">Aziende</a>
            <a href="#">Scuole</a>
        </div>

        <div class="logAndSign">
            <a class="button_1" href="../login/login.html">ACCEDI</a>
        </div>
    </nav>
    <div id="main">
        <div id="loginCard">
            <h1>Registrazione Studente</h1>
            <form method="POST">
                <div class="input">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" placeholder="Username" required>
                </div>
                <div class="input">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" placeholder="Password" required>
                </div>
                <div class="input">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" placeholder="Email" required>
                </div>
                <div class="input">
                    <label for="a_email">Email Scolastica</label>
                    <input type="email" name="a_email" id="a_email" placeholder="Email Scolastica">
                </div>
                <input type="submit" value="Accedi">
            </form>
            <a class="turn-back-button" href="./signin.html">
                <img src="../assests/back-icon-png-16-101190050.jpg" alt="back_icon">
            </a>
        </div>
    </div>
    <footer>
        <div class="info">
            <a href="#">I Nostri Servizi</a>
            <a href="#">Scopri il Nostro Team</a>
            <a href="#">Dacci un Feedback</a>
        </div>
        <div class="marketing">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Mollitia rem cum perferendis fugiat delectus ipsum eligendi, hic beatae magnam omnis nam dolor fuga praesentium consequatur at voluptates ad dolore repellendus!</div>
        <div class="link">
            <a href="#">I Nostri Servizi</a>
            <a href="#">Scopri il Nostro Team</a>
            <a href="#">Dacci un Feedback</a>
        </div>
    </footer>
</body>

</html>
