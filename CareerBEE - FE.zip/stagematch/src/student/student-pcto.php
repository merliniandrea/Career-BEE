<?php
session_start();  // Avvia la sessione
?>

<?php
// Funzione per inviare la richiesta al server tramite GET per partecipare al progetto
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['join_project'])) {
    $user_id = $_SESSION["user_id"];  // Prendi l'ID utente dalla sessione
    $project_id = $_GET['id_project'];  // Prendi l'ID progetto dalla query string

    // Dati da inviare con la richiesta GET
    $data = array(
        "id_user" => $user_id,
        "id_project" => $project_id
    );

    // Debug: Stampa il corpo JSON prima di inviarlo
    echo "<pre>";
    echo "Corpo della richiesta JSON:\n";
    print_r($data);  // Mostra il contenuto dell'array prima della conversione in JSON
    echo "</pre>";

    // URL per la richiesta GET
    $url = "https://744e-2-115-95-150.ngrok-free.app/Hackaton/api/project/join.php?id_user={$data['id_user']}&id_project={$data['id_project']}";

    // Inizializza cURL
    $ch = curl_init($url);

    // Configura cURL per inviare una richiesta GET
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPGET, true);

    // Esegui la richiesta
    $response = curl_exec($ch);

    // Debug: Controlla se c'è stato un errore
    if (curl_errno($ch)) {
        echo "Errore cURL: " . curl_error($ch);
    } else {
        $response_data = json_decode($response, true);
        // Puoi aggiungere logica per gestire la risposta (ad esempio, messaggio di successo)
        echo "<p>Hai partecipato al progetto con ID: $project_id</p>";
        $message = $response_data["message"];
        echo "<p>Risposta: $message</p>";
    }

    // Chiudi la sessione cURL
    curl_close($ch);
}

// Funzione per fare la chiamata GET per ottenere i progetti
function fetchProjects($id_project = null)
{
    $url = "https://744e-2-115-95-150.ngrok-free.app/Hackaton/api/project/get.php";
    if ($id_project) {
        $url .= "?id=$id_project";  // Se è stato passato un id, aggiungilo all'URL
    }

    // Inizializza cURL per la richiesta GET
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPGET, true);
    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo "Errore cURL: " . curl_error($ch);
    }
    curl_close($ch);

    // Restituisci il risultato in formato array associativo
    return json_decode($response, true);
}

// Recupera i progetti
$projects = fetchProjects();
?>

<!DOCTYPE html>
<html lang="it">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../global.css">
    <link rel="stylesheet" href="./student.css">
    <title>Document</title>
</head>

<body>
    <nav class="navbar">
        <div class="menu">
            <div class="logo-wrapper">
                <img class="logo-app" src="../assests/logo-app.png" alt="logo_img">
                <a href="../index/index.html" class="logo">CareerBEE</a>
            </div>
            <a href="#">Aziende</a>
            <a href="#">Scuole</a>
        </div>

        <div class="logAndSign">

            <a class="user_logo" href="../user/user.html">
                <img src="../assests/account-icon-png-2-292153647.jpg" alt="user_icon">
            </a>
        </div>
    </nav>
    <div id="main">
        <div class="pcto-viewer">
            <form action="" method="GET">
                <input type="number" name="id_project" id="id_project" placeholder="ID Progetto">
                <input type="submit" name="submit" value="Stampa Progetti">
            </form>
            <form action="../student/student-dashboard.html" method="get"><br><br><br>
                <button type="submit">Vai alla pagina principale dello Studente</button>
            </form>
            <?php
        if (!empty($projects)) {
            echo "<h3>Elenco Progetti:</h3>";
            echo "<div class='projects-container'>";
            foreach ($projects as $project) {
                // Controllo se un progetto è stato selezionato
                $detailsDisplayed = isset($_GET['id']) && $_GET['id'] == $project['id'] ? 'block' : 'none';

                echo "<div class='project-card' onclick='toggleDetails({$project['id']})'>";
                echo "ID: " . htmlspecialchars($project['id']) . "<br>";
                echo "Nome: " . htmlspecialchars($project['nome']) . "<br>";
                echo "Nome azienda: " . htmlspecialchars($project['enterprise_name']);
                echo "<form method='GET' action=''>
                        <input type='hidden' name='id_project' value='" . htmlspecialchars($project['id']) . "'>
                        <button type='submit' name='join_project' class='join-button'>Partecipa</button>
                      </form>";
                echo "</div>";

                // Dettagli del progetto, visualizzati solo se è stato selezionato
                echo "<div class='project-details' id='details-{$project['id']}' style='display: $detailsDisplayed'>";
                echo "<strong>Dettagli Progetto:</strong><br>";
                echo "ID: " . htmlspecialchars($project['id']) . "<br>";
                echo "Nome: " . htmlspecialchars($project['nome']) . "<br>";
                echo "Nome azienda: " . htmlspecialchars($project['enterprise_name']);
                // Aggiungi ulteriori dettagli se presenti
                echo "</div>";
            }
            echo "</div>";
        } else {
            echo "<p>Nessun progetto trovato.</p>";
        }
        ?>
        </div>
    </div>
    <footer>
        <div class="info">
            <a href="#">I Nostri Servizi</a>
            <a href="#">Scopri il Nostro Team</a>
            <a href="#">Dacci un Feedback</a>
        </div>
        <div class="marketing">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Mollitia rem cum perferendis fugiat delectus ipsum eligendi, hic beatae magnam omnis nam dolor fuga praesentium consequatur at voluptates ad dolore repellendus!</div>
        <div class="link">
            <a href="#">I Nostri Servizi</a>
            <a href="#">Scopri il Nostro Team</a>
            <a href="#">Dacci un Feedback</a>
        </div>
    </footer>

    <script>
        function toggleDetails(projectId) {
            const detailsElement = document.getElementById('details-' + projectId);

            // Nascondi tutti i dettagli
            const allDetails = document.querySelectorAll('.project-details');
            allDetails.forEach(function(detail) {
                if (detail !== detailsElement) {
                    detail.style.display = 'none';
                }
            });

            // Toggle la visibilità del dettaglio selezionato
            if (detailsElement.style.display === 'block') {
                detailsElement.style.display = 'none';
            } else {
                detailsElement.style.display = 'block';
            }
        }
    </script>
</body>

</html>
