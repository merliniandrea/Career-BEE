<?php

// Intestazioni per consentire CORS e metodi di richiesta specifici
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

// Connessione al database MySQL
$host = '127.0.0.1'; // Indirizzo del server locale
$dbname = 'Hackaton'; // Nome del tuo database
$username = 'root'; // Username predefinito di XAMPP
$password = ''; // Password di default per XAMPP (vuota)

try {
    // Connessione a MySQL tramite PDO
    $db = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Imposta l'encoding per evitare problemi con caratteri speciali
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Gestisci l'errore e restituisci un errore in formato JSON
    echo json_encode(['error' => "Connessione fallita: " . $e->getMessage()]);
    exit;
}

// Verifica se è stato inviato un postback (metodo POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Caso 1: Quando si inviano gli interessi
    if (isset($_POST['interessi']) && !empty($_POST['interessi'])) {

        $interessi = trim($_POST['interessi']);
        $interessi_like = "%" . strtolower($interessi) . "%";

        // Esegui la query per trovare aziende che corrispondono agli interessi
        $query = "SELECT * FROM aziende WHERE LOWER(area_lavoro) LIKE :interessi";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':interessi', $interessi_like);
        $stmt->execute();

        $aziende = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($aziende) > 0) {
            echo json_encode(['success' => true, 'aziende' => $aziende]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Nessuna azienda trovata per questi interessi.']);
        }

    // Caso 2: Quando si inviano i punteggi per determinare i settori più pertinenti
    } elseif (isset($_POST['punteggi']) && !empty($_POST['punteggi'])) {

        // Decodifica il JSON dei punteggi ricevuti
        $punteggi = json_decode($_POST['punteggi'], true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(['error' => 'Errore nella decodifica JSON.']);
            exit;
        }

        // Creiamo un array dei settori ordinati per punteggio (decrescente)
        arsort($punteggi); // Ordina i punteggi in ordine decrescente

        // Prendi i settori con i punteggi più alti
        $settori_interessanti = array_keys($punteggi);

        // Prepara la query dinamica per selezionare le aziende che appartengono ai settori più pertinenti
        $conditions = [];
        foreach ($settori_interessanti as $settore) {
            $conditions[] = "LOWER(area_lavoro) LIKE ?";
        }

        // Combina le condizioni in un'unica query
        $query = "SELECT nome, area_lavoro FROM aziende WHERE " . implode(" OR ", $conditions);

        try {
            // Prepara ed esegui la query con i settori ordinati
            $stmt = $db->prepare($query);

            // Aggiungi i valori dei settori come parametri nella query
            $parameters = [];
            foreach ($settori_interessanti as $settore) {
                $parameters[] = "%" . strtolower($settore) . "%"; // Aggiungiamo il wildcard % per il LIKE
            }

            // Esegui la query
            $stmt->execute($parameters);

            // Recupera i risultati
            $aziende = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Verifica se ci sono aziende
            if (count($aziende) > 0) {
                echo json_encode(['success' => true, 'aziende' => $aziende]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Nessuna azienda trovata per questi settori.']);
            }

        } catch (PDOException $e) {
            // Gestione errori nella query
            echo json_encode(['error' => 'Errore nella query: ' . $e->getMessage()]);
            exit;
        }

    // Caso 3: Quando la richiesta non è valida o non sono stati inviati né gli interessi né i punteggi
    } else {
        echo json_encode(['success' => false, 'message' => 'Richiesta non valida.']);
    }
}

?>
