<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Recupera i parametri GET
    $data = $_GET;
    if (isset($data['email']) && isset($data['password'])) {
        require('../db_info.php');

        // Connessione al database
        $conn = new mysqli($host, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }

        $password = $conn->real_escape_string($data['password']);
        $email = $conn->real_escape_string($data['email']);

        $sql = "SELECT password, email, id FROM enterprises WHERE password = '$password' AND email = '$email'";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            http_response_code(200);
            echo json_encode(["message" => "User found", "login" => true, "id" => $row["id"]]);
        } else {
            echo json_encode(["message" => "User not found", "login" => false]);
        }

        $conn->close(); // Chiudi la connessione
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Missing required parameters"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}
?>