<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require('../db_info.php');

    // Connessione al database
    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    // Recupera i parametri della richiesta
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (isset($data['id_user']) && isset($data['id_project']) && isset($data['mark'])) {
        $id_user = $conn->real_escape_string($data['id_user']);
        $id_project = $conn->real_escape_string($data['id_project']);
        $mark = $conn->real_escape_string($data['mark']);
        $comment = isset($data['comment']) ? $conn->real_escape_string($data['comment']) : NULL;

        // Imposta l'id a "V" (fisso)
        $id = 'V';

        // Query per inserire i dati nella tabella valutation
        $insertSql = "INSERT INTO valutation (id_user, id_project, id, mark, comment) 
                      VALUES ('$id_user', '$id_project', '$id', '$mark', '$comment')";

        if ($conn->query($insertSql) === TRUE) {
            // Se l'inserimento è riuscito, aggiorna lo stato nella tabella user_project
            $updateSql = "UPDATE user_project 
                          SET stato = 'COMPLETATO' 
                          WHERE id_user = '$id_user' AND id_project = '$id_project'";

            if ($conn->query($updateSql) === TRUE) {
                http_response_code(200);
                echo json_encode(["message" => "Record added and project state updated successfully"]);
            } else {
                echo json_encode(["message" => "Error updating project state: " . $conn->error]);
            }
        } else {
            echo json_encode(["message" => "Error: " . $conn->error]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Missing required parameters"]);
    }

    $conn->close(); // Chiudi la connessione
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}
