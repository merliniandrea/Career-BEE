<?php
    $host = "localhost";  // Indirizzo del server (di solito "localhost" su XAMPP)
    $username = "root";   // Nome utente di default su XAMPP
    $password = "";       // Password di default su XAMPP (vuota)
    $dbname = "hackaton"; // Nome del tuo database
?>