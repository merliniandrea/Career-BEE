<?php
// Aggiungi le intestazioni CORS
header("Access-Control-Allow-Origin: *");  // Consente tutte le origini
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");  // Consente i metodi GET, POST, OPTIONS
header("Access-Control-Allow-Headers: Content-Type, Authorization");  // Consente intestazioni specifiche

// Gestisci le richieste OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // Rispondi con un codice 200 (OK) per la richiesta OPTIONS
    http_response_code(200);
    exit;  // Termina l'esecuzione per le richieste OPTIONS
}

// Ora gestisci le richieste GET o POST come normale
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Recupera i parametri GET
    $data = $_GET;
    if (isset($data['username']) && isset($data['password'])) {
        require('../db_info.php');

        // Connessione al database
        $conn = new mysqli($host, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }

        $password = $conn->real_escape_string($data['password']);
        $username = $conn->real_escape_string($data['username']);

        $sql = "SELECT password, username, id FROM users WHERE password = '$password' AND username = '$username'";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            http_response_code(200);  // OK
            echo json_encode(["message" => "User found", "login" => true, "id" => $row["id"]]);
        } else {
            echo json_encode(["message" => "User not found", "login" => false]);
        }

        $conn->close();
    } else {
        http_response_code(400);  // Bad Request
        echo json_encode(["message" => "Missing required parameters"]);
    }
} else {
    http_response_code(405);  // Method Not Allowed
    echo json_encode(["message" => "Method not allowed"]);
}
