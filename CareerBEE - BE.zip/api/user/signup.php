<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recupera i dati del corpo della richiesta POST
    $data = json_decode(file_get_contents('php://input'), true);
    if (isset($data['username']) && isset($data['email']) && isset($data['password'])) {
        require('../db_info.php');

        // Connessione al database
        $conn = new mysqli($host, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }

        $username = $conn->real_escape_string($data['username']);
        $email = $conn->real_escape_string($data['email']);
        $password = $conn->real_escape_string($data['password']);
        $type = isset($data['additional_email']) ? 'STUD' : 'EXSTUD';
        $additional_email = isset($data['additional_email']) ? $conn->real_escape_string($data['additional_email']) : NULL;

        // Analisi del dominio dall'additional_email
        $aptf_scuola = null;
        if ($additional_email) {
            $parts = explode('@', $additional_email);
            if (count($parts) === 2) {
                $dominio = $conn->real_escape_string($parts[1]);

                // Verifica il dominio nella tabella scuola e ottieni la aptf
                $checkAptfSql = "SELECT aptf FROM scuola WHERE dominio = '$dominio'";
                $checkAptfResult = $conn->query($checkAptfSql);

                if ($checkAptfResult && $checkAptfResult->num_rows > 0) {
                    $row = $checkAptfResult->fetch_assoc();
                    $aptf_scuola = $row['aptf'];
                } else {
                    http_response_code(400);
                    echo json_encode(["message" => "Invalid school domain"]);
                    $conn->close();
                    exit;
                }
            }
        }

        // Verifica se l'utente esiste già
        $checkSql = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
        $checkResult = $conn->query($checkSql);

        if ($checkResult && $checkResult->num_rows > 0) {
            echo json_encode(["message" => "User already exists"]);
        } else {
            // Query per inserire il nuovo utente
            $insertSql = "INSERT INTO users (username, email, additional_email, password, type, aptf_scuola) VALUES (
                '$username',
                '$email',
                " . ($additional_email ? "'$additional_email'" : "NULL") . ",
                '$password',
                '$type',
                " . ($aptf_scuola ? "'$aptf_scuola'" : "NULL") . "
            )";

            if ($conn->query($insertSql) === TRUE) {
                http_response_code(200);
                echo json_encode(["message" => "Signup successful"]);
            } else {
                echo json_encode(["message" => "Error: " . $conn->error]);
            }
        }

        $conn->close(); // Chiudi la connessione
    } else {
        http_response_code(400);
        $pass = isset($data['password']);
        $use = isset($data['username']);
        $ema = isset($data['email']);
        echo json_encode(["message" => "Missing required parameters"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}
