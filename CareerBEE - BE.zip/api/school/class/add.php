<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require('../../db_info.php');

    // Connessione al database
    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    // Recupera i dati dalla richiesta POST (assumendo che siano passati in formato JSON)
    $data = json_decode(file_get_contents('php://input'), true);

    // Verifica che i parametri necessari siano presenti
    if (isset($data['id']) && isset($data['n'])) {
        $id = $conn->real_escape_string($data['id']);
        $n = ($data['n'] === null) ? 'NULL' : (int)$data['n'];

        // Query per inserire i dati nella tabella
        $sql = "INSERT INTO class (id, n) VALUES ('$id', $n)";

        // Esegui la query
        if ($conn->query($sql) === TRUE) {
            http_response_code(200);
            echo json_encode(["message" => "Dati inseriti con successo"]);
        } else {
            echo json_encode(["message" => "Errore: " . $conn->error]);
        }
    } else {
        // Se manca un parametro, restituisce un errore
        http_response_code(400);
        echo json_encode(["message" => "Parametro mancante"]);
    }

    $conn->close(); // Chiudi la connessione
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}
?>
