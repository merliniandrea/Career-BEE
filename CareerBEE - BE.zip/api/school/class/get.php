<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Connessione al database
    require('../../db_info.php');
    $conn = new mysqli($host, $username, $password, $dbname);

    // Controlla la connessione al database
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    // Recupera il parametro 'class' dalla query string
    if (isset($_GET['class'])) {
        $class = $conn->real_escape_string($_GET['class']);

        // Verifica se la classe esiste nella tabella 'class'
        $checkClassSql = "SELECT id FROM class WHERE id = '$class'";
        $checkResult = $conn->query($checkClassSql);

        if ($checkResult && $checkResult->num_rows > 0) {
            // La classe esiste, recupera tutti gli utenti associati
            $getUsersSql = "SELECT id, username, email, additional_email 
                            FROM users 
                            WHERE class = '$class'";

            $usersResult = $conn->query($getUsersSql);

            if ($usersResult && $usersResult->num_rows > 0) {
                $users = [];

                while ($row = $usersResult->fetch_assoc()) {
                    $users[] = $row;
                }

                // Restituisci i dati in formato JSON
                echo json_encode([$users]);
            } else {
                // Nessun utente trovato per questa classe
                echo json_encode(["message" => "No users found for class '$class'"]);
            }
        } else {
            // La classe non esiste
            echo json_encode(["message" => "Class '$class' does not exist"]);
        }
    } else {
        echo json_encode(["message" => "Missing parameter: class"]);
    }

    $conn->close(); // Chiudi la connessione al database
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}
?>
