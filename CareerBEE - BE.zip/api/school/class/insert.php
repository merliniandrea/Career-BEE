<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Connessione al database
    require('../../db_info.php');
    $conn = new mysqli($host, $username, $password, $dbname);

    // Controlla la connessione al database
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    // Recupera il parametro 'class' dalla query string
    if (isset($_GET['class']) && isset($_GET['id_user'])) {
        $class = $conn->real_escape_string($_GET['class']);
        $id_user = $conn->real_escape_string($_GET['id_user']);

        // Verifica se la classe esiste nella tabella 'class'
        $checkClassSql = "SELECT id FROM class WHERE id = '$class'";
        $checkResult = $conn->query($checkClassSql);

        if ($checkResult && $checkResult->num_rows > 0) {
            // La classe esiste, procediamo ad aggiornare la colonna 'class' nell'utente
            $updateSql = "UPDATE users SET class = '$class' WHERE id = '$id_user'";

            if ($conn->query($updateSql) === TRUE) {
                http_response_code(200);
                echo json_encode(["message" => "Class updated successfully for user ID $id_user"]);
            } else {
                echo json_encode(["message" => "Error updating class: " . $conn->error]);
            }
        } else {
            // La classe non esiste
            echo json_encode(["message" => "Class '$class' does not exist"]);
        }
    } else {
        echo json_encode(["message" => "Missing parameters: class and id_user"]);
    }

    $conn->close(); // Chiudi la connessione al database
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}
?>
