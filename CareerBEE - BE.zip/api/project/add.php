<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recupera i dati del corpo della richiesta POST
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['nome'], $data['posti'], $data['d_inizio'], $data['id_azienda'])) {
        require('../db_info.php');

        // Connessione al database
        $conn = new mysqli($host, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }

        $nome = $conn->real_escape_string($data['nome']);
        $posti = (int)$data['posti'];
        $d_inizio = $conn->real_escape_string($data['d_inizio']);
        $d_fine = isset($data['d_fine']) ? $conn->real_escape_string($data['d_fine']) : null;
        $id_azienda = (int)$data['id_azienda'];

        // Verifica se l'azienda esiste
        $checkEnterpriseSql = "SELECT * FROM enterprises WHERE id = $id_azienda";
        $enterpriseResult = $conn->query($checkEnterpriseSql);

        if ($enterpriseResult && $enterpriseResult->num_rows > 0) {
            // Inserisci il progetto se l'azienda esiste
            $insertSql = "INSERT INTO projects (nome, posti, d_inizio, d_fine, id_azienda) VALUES ('$nome', $posti, '$d_inizio', " . ($d_fine ? "'$d_fine'" : "NULL") . ", $id_azienda)";

            if ($conn->query($insertSql) === TRUE) {
                http_response_code(200);
                echo json_encode(["message" => "Project created successfully"]);
            } else {
                echo json_encode(["message" => "Error: " . $conn->error]);
            }
        } else {
            http_response_code(404);
            echo json_encode(["message" => "Enterprise not found"]);
        }

        $conn->close(); // Chiudi la connessione
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Missing required parameters"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}

