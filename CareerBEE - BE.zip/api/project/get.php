<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    require('../db_info.php');

    // Connessione al database
    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    // Controlla se è stato passato un parametro id
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $id = $conn->real_escape_string($_GET['id']);

        // Query per ottenere tutte le informazioni di un singolo progetto
        $sql = "
            SELECT 
                p.*, 
                e.nome AS enterprise_name 
            FROM 
                projects p
            LEFT JOIN 
                enterprises e 
            ON 
                p.id_azienda = e.id
            WHERE 
                p.id = $id
        ";
    } else {
        // Query per ottenere solo id, nome e nome dell'azienda per tutti i progetti
        $sql = "
            SELECT 
                p.id, 
                p.nome, 
                e.nome AS enterprise_name,
                p.d_inizio,
                p.d_fine,
                p.posti
            FROM 
                projects p
            LEFT JOIN 
                enterprises e 
            ON 
                p.id_azienda = e.id
        ";
    }

    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $projects = [];
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
        http_response_code(200);
        echo json_encode($projects);
    } else {
        echo json_encode([]);
    }

    $conn->close(); // Chiudi la connessione
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}
