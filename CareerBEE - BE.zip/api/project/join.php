<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    require('../db_info.php');

    // Connessione al database
    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    // Controlla se sono stati forniti i parametri necessari
    if (isset($_GET['id_user']) && isset($_GET['id_project']) && is_numeric($_GET['id_user']) && is_numeric($_GET['id_project'])) {
        $id_user = $conn->real_escape_string($_GET['id_user']);
        $id_project = $conn->real_escape_string($_GET['id_project']);

        // Query per verificare se il progetto e l'utente esistono
        $userCheckSql = "SELECT id FROM users WHERE id = $id_user";
        $projectCheckSql = "SELECT id FROM projects WHERE id = $id_project";

        $userCheckResult = $conn->query($userCheckSql);
        $projectCheckResult = $conn->query($projectCheckSql);

        if ($userCheckResult && $userCheckResult->num_rows > 0 && $projectCheckResult && $projectCheckResult->num_rows > 0) {
            // Verifica se il record esiste già nella tabella
            $checkSql = "SELECT * FROM user_project WHERE id_user = $id_user AND id_project = $id_project";
            $checkResult = $conn->query($checkSql);

            if ($checkResult && $checkResult->num_rows > 0) {
                echo json_encode(["message" => "Record already exists"]);
            } else {
                // Inserisce il nuovo record nella tabella user_project
                $insertSql = "INSERT INTO user_project (id_user, id_project, stato) VALUES ($id_user, $id_project, 'IN SOSPESO')";
                if ($conn->query($insertSql) === TRUE) {
                    http_response_code(200);
                    echo json_encode(["message" => "Record added successfully"]);
                } else {
                    echo json_encode(["message" => "Error: " . $conn->error]);
                }
            }
        } else {
            echo json_encode(["message" => "Invalid user or project ID"]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Missing or invalid parameters"]);
    }

    $conn->close(); // Chiudi la connessione
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}
