<?php
header('Content-Type: application/json');

$request = trim($_SERVER['REQUEST_URI'], '/');
$method = $_SERVER['REQUEST_METHOD'];

// Aggiungi un controllo per mappare file senza estensione
if (!str_ends_with($request, '.php')) {
    $request .= '.php';
}

$filePath = __DIR__ . '/' . $request;

if (file_exists($filePath)) {
    require $filePath;
} else {
    http_response_code(404);
    echo json_encode(["message" => "Endpoint not found"]);
}
